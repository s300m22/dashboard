<?php  //admin/language/en-gb/extention/module
// Heading
$_['heading_title']    = 'Helloworld';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified helloworld module!';
$_['text_edit']        = 'Edit Helloworld Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify helloworld module!';